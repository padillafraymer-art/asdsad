<footer class="py-4 bg-light mt-auto">
    <div class="container-fluid px-4">
        <div class="d-flex align-items-center justify-content-between small">
            <div class="text-muted">Copyleft &copy; Equipo desarrollador 2025</div>
        </div>
    </div>
</footer>
</div>
</div>
 
<script src="js/bootstrap.js"></script>
<script src="js/scripts.js"></script>
<script src="js/datatables.js"></script>
<script src="js/datatables-simple-demo.js"></script>
</body>
</html>
